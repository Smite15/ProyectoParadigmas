package funcional2;
import java.util.*;
import java.util.stream.Collectors;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Saul Mite
 */
public class NombresFuncional {
  public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        Set<String> nombres = new HashSet<>();

        System.out.println("Ingresa nombres (deja en blanco para terminar):");
        while (true) {
            String nombre = sc.nextLine().trim();
            if (nombre.isEmpty()) break;
            if (!nombres.add(nombre)) {
                System.out.println("Nombre repetido, no se agregará.");
            }
        }

        System.out.println("\nLista de nombres únicos y ordenados alfabeticamente:");
        nombres.stream()
                .sorted()
                .forEach(System.out::println);
    }
}
