/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcional2;
import java.util.*;
import java.util.stream.*;

/**
 *
 * @author Saul Mite
 */

public class PalabrasFuncional {

    public static void ejecutar() {
        Scanner scanner = new Scanner(System.in);
        List<String> palabras = new ArrayList<>();

        System.out.println("Ingresa palabras (vacío para terminar):");
        while (true) {
            String palabra = scanner.nextLine().trim();
            if (palabra.isEmpty()) break;
            palabras.add(palabra);
        }

        long cantidadVocales = palabras.stream()
            .filter(p -> !p.isEmpty())
            .filter(p -> "aeiou".indexOf(Character.toLowerCase(p.charAt(0))) >= 0)
            .count();

        System.out.println("Palabras que empiezan con vocal: " + cantidadVocales);
    }
}