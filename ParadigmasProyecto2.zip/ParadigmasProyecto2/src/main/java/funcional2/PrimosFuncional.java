/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcional2;
import java.util.Scanner;
import java.util.stream.IntStream;
/**
 *
 * @author Saul Mite
 */
public class PrimosFuncional {
public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuantos números primos deseas mostrar? ");
        int n = sc.nextInt();

        System.out.println("Primeros " + n + " numeros primos:");

        IntStream.iterate(2, i -> i + 1) // stream infinito desde 2
                .filter(PrimosFuncional::esPrimo)
                .limit(n)
                .forEach(System.out::println);
    }

    // Función pura para validar si un número es primo
    private static boolean esPrimo(int num) {
        return num > 1 &&
               IntStream.rangeClosed(2, (int)Math.sqrt(num))
                        .noneMatch(i -> num % i == 0);
    }
}
