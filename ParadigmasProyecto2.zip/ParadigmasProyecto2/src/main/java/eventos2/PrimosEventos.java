/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos2;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.stream.*;
/**
 *
 * @author Saul Mite
 */
public class PrimosEventos {
 public void ejecutar() {
        JFrame frame = new JFrame("Numeros Primos (Eventos)");

        JTextField input = new JTextField(10);
        JButton calcular = new JButton("Calcular Primos");
        JTextArea resultado = new JTextArea(10, 25);
        resultado.setEditable(false);

        calcular.addActionListener(e -> {
            try {
                int n = Integer.parseInt(input.getText());
                String primos = IntStream.iterate(2, i -> i + 1)
                        .filter(PrimosEventos::esPrimo)
                        .limit(n)
                        .mapToObj(Integer::toString)
                        .collect(Collectors.joining(", "));
                resultado.setText("Primeros " + n + " primos:\n" + primos);
            } catch (NumberFormatException ex) {
                resultado.setText("Entrada inválida.");
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Cantidad de primos:"));
        panel.add(input);
        panel.add(calcular);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(resultado), BorderLayout.CENTER);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private static boolean esPrimo(int num) {
        return num > 1 && IntStream.rangeClosed(2, (int) Math.sqrt(num))
                .noneMatch(i -> num % i == 0);
    }
}