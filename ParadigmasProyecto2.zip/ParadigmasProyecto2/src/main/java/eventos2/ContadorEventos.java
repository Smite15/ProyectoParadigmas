/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos2;

import java.util.Scanner;

/**
 *
 * @author Saul Mite
 */
public class ContadorEventos{
    private int contador = 0;
    private int totalIncrementos = 0;
    private int totalDecrementos = 0;

    private final Scanner sc = new Scanner(System.in);

    public ContadorEventos() {
        mostrarMenu();
    }

    private void mostrarMenu() {
        int opcion;

        do {
            System.out.println("\n========= CONTADOR DE EVENTOS =========");
            System.out.println("Valor actual: " + contador);
            System.out.println("[1] Incrementar");
            System.out.println("[2] Decrementar");
            System.out.println("[3] Reiniciar");
            System.out.println("[4] Mostrar historial");
            System.out.println("[0] Salir al menu principal");
            System.out.print("Seleccione una opcion: ");

            opcion = sc.nextInt();
            sc.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> incrementar();
                case 2 -> decrementar();
                case 3 -> reiniciar();
                case 4 -> mostrarHistorial();
                case 0 -> System.out.println("Saliendo del contador...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);
    }

    private void incrementar() {
        contador++;
        totalIncrementos++;
        System.out.println("Contador incrementado. Nuevo valor: " + contador);
    }

    private void decrementar() {
        if (contador > 0) {
            contador--;
            totalDecrementos++;
            System.out.println("Contador decrementado. Nuevo valor: " + contador);
        } else {
            System.out.println("El contador ya está en cero.");
        }
    }

    private void reiniciar() {
        contador = 0;
        totalIncrementos = 0;
        totalDecrementos = 0;
        System.out.println("Contador reiniciado a cero.");
    }

    private void mostrarHistorial() {
        System.out.println("\n HISTORIAL DEL CONTADOR:");
        System.out.println("Valor actual: " + contador);
        System.out.println("Total incrementos: " + totalIncrementos);
        System.out.println("Total decrementos: " + totalDecrementos);
    }
}
