/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos2;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
/**
 *
 * @author Saul Mite
 */
public class NombresEventos {
   public void ejecutar() {
        JFrame frame = new JFrame("Lista de Nombres (Eventos)");
        DefaultListModel<String> modelo = new DefaultListModel<>();
        Set<String> nombresUnicos = new HashSet<>();

        JTextField campo = new JTextField(15);
        JButton agregar = new JButton("Agregar");
        JButton mostrar = new JButton("Mostrar Ordenados");
        JTextArea area = new JTextArea(10, 20);

        agregar.addActionListener(e -> {
            String nombre = campo.getText().trim();
            if (!nombre.isEmpty()) {
                if (nombresUnicos.add(nombre)) {
                    modelo.addElement(nombre);
                } else {
                    JOptionPane.showMessageDialog(frame, "Nombre repetido.");
                }
                campo.setText("");
            }
        });

        mostrar.addActionListener(e -> {
            List<String> ordenados = new ArrayList<>(nombresUnicos);
            Collections.sort(ordenados);
            area.setText("Nombres ordenados:\n");
            ordenados.forEach(n -> area.append(n + "\n"));
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Nombre:"));
        panel.add(campo);
        panel.add(agregar);
        panel.add(mostrar);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(area), BorderLayout.CENTER);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
