/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.*;
/**
 *
 * @author Saul Mite
 */
public class GestorNombres {
private final Set<String> nombres = new HashSet<>();

    public boolean agregarNombre(String nombre) {
        return nombres.add(nombre.trim());
    }

    public List<String> obtenerNombresOrdenados() {
        List<String> lista = new ArrayList<>(nombres);
        Collections.sort(lista);
        return lista;
    }
}

