/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.*;
/**
 *
 * @author Saul Mite
 */
public class Carrito {
    private List<Producto> productos = new ArrayList<>();

    public void agregarProducto(Producto p) {
        productos.add(p);
    }

    public double calcularTotal() {
        return productos.stream().mapToDouble(Producto::getPrecio).sum();
    }

    public void mostrarProductos() {
        for (Producto p : productos) {
            System.out.println(p.getNombre() + ": $" + p.getPrecio());
        }
    }
}