/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.*;
/**
 *
 * @author Saul Mite
 */
public class TiendaApp {
     public static void ejecutar() {
        Scanner scanner = new Scanner(System.in);
        Carrito carrito = new Carrito();

        while (true) {
            System.out.print("Nombre del producto (vacio para terminar): ");
            String nombre = scanner.nextLine().trim();
            if (nombre.isEmpty()) break;

            System.out.print("Precio: ");
            double precio = Double.parseDouble(scanner.nextLine());

            carrito.agregarProducto(new Producto(nombre, precio));
        }

        System.out.println("\nProductos en el carrito:");
        carrito.mostrarProductos();
        System.out.printf("Total a pagar: $%.2f\n", carrito.calcularTotal());
    }
}
