/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.Scanner;
/**
 *
 * @author Saul Mite
 */
public class NombresPOO {
 private final GestorNombres gestor = new GestorNombres();
    private final Scanner sc = new Scanner(System.in);

    public void ejecutar() {
        System.out.println("=== Modulo Nombres POO ===");

        while (true) {
            System.out.println("\n1. Agregar nombre");
            System.out.println("2. Mostrar ordenados");
            System.out.println("3. Salir");

            System.out.print("Elige una opcion: ");
            String op = sc.nextLine();

            switch (op) {
                case "1" -> {
                    System.out.print("Ingresa un nombre: ");
                    String nombre = sc.nextLine();
                    if (nombre.isBlank()) {
                        System.out.println("Nombre vacio no permitido.");
                    } else if (gestor.agregarNombre(nombre)) {
                        System.out.println("Nombre agregado.");
                    } else {
                        System.out.println("Nombre repetido.");
                    }
                }
                case "2" -> {
                    System.out.println("Nombres ordenados:");
                    for (String nombre : gestor.obtenerNombresOrdenados()) {
                        System.out.println(nombre);
                    }
                }
                case "3" -> {
                    System.out.println("Saliendo de nombres POO...");
                    return;
                }
                default -> System.out.println("Opcion invalida.");
            }
        }
    }
}
