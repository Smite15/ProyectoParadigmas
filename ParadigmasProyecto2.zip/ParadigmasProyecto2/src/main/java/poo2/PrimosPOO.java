/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Saul Mite
 */
public class PrimosPOO {
 private final Scanner sc = new Scanner(System.in);
    private final GeneradorPrimos generador = new GeneradorPrimos();

    public void ejecutar() {
        System.out.println("=== Modulo Primos POO ===");

        while (true) {
            System.out.println("\n1. Ver N numeros primos");
            System.out.println("2. Salir");

            System.out.print("Elige opcion: ");
            String op = sc.nextLine();

            switch (op) {
                case "1" -> {
                    System.out.print("¿Cuantos primos deseas?: ");
                    int n = Integer.parseInt(sc.nextLine());

                    List<Integer> primos = generador.obtenerPrimos(n);
                    System.out.println("Primos:");
                    primos.forEach(p -> System.out.print(p + " "));
                    System.out.println();
                }
                case "2" -> {
                    System.out.println("Saliendo de primos POO...");
                    return;
                }
                default -> System.out.println("Opcion invalida.");
            }
        }
    }
}

