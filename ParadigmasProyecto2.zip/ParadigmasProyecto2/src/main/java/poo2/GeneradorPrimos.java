/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo2;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Saul Mite
 */
public class GeneradorPrimos {
public List<Integer> obtenerPrimos(int cantidad) {
        List<Integer> primos = new ArrayList<>();
        int num = 2;

        while (primos.size() < cantidad) {
            if (esPrimo(num)) {
                primos.add(num);
            }
            num++;
        }
        return primos;
    }

    private boolean esPrimo(int numero) {
        if (numero < 2) return false;
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) return false;
        }
        return true;
    }
}
