/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.paradigmasproyecto2;
import funcional2.NombresFuncional;
import estructurado2.*;
import poo2.*;
import eventos2.*;
import funcional2.*;

import java.util.Scanner;
/**
 *
 * @author Saul Mite
 */
public class ParadigmasProyecto2 {
 public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=======================================");
            System.out.println("Selecciona el paradigma a ejecutar:");
            System.out.println("1. Programacion Estructurada");
            System.out.println("2. Programacion Orientada a Objetos");
            System.out.println("3. Programacion Orientada a Eventos");
            System.out.println("4. Programacion Funcional");
            System.out.println("5. Salir del programa");
            System.out.println("=======================================");
            System.out.print("Elige la funcion deseada: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> menuEstructurado(sc);
                case 2 -> menuPOO(sc);
                case 3 -> menuEventos(sc);
                case 4 -> menuFuncional(sc);
                case 5 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opcion invalida.");
            }

            if (opcion != 5) {
                System.out.println("\nPresiona ENTER para volver al menu principal...");
                sc.nextLine(); // espera ENTER
            }

        } while (opcion != 5);

        System.out.println("Gracias por usar el sistema de demostracion de paradigmas.");
    }

    // Submenú ESTRUCTURADO
    public static void menuEstructurado(Scanner sc) {
        int subop;
        do {
            System.out.println("\n--- MODULO ESTRUCTURADO ---");
            System.out.println("1. Promedio de calificaciones");
            System.out.println("2. Lista de nombres sin repetidos y ordenados");
            System.out.println("3. Ver primeros N numeros primos");
            System.out.println("4. Volver al menu principal");
            System.out.print("Elige opcion: ");
            subop = sc.nextInt();
            sc.nextLine();

            switch (subop) {
                    case 1 -> PromedioEstructurado.ejecutar();
                    case 2 -> NombresEstructurado.ejecutar();
                    case 3 -> PrimosEstructurado.ejecutar(); // Aquí sí va el de primos
                    case 4 -> System.out.println("Volviendo...");
                    default -> System.out.println("Opcion invalida.");
}
        } while (subop != 4);
    }

    // Submenú POO
    public static void menuPOO(Scanner sc) {
        int subop;
        do {
            System.out.println("\n--- MODULO POO ---");
            System.out.println("1. Lista de nombres (sin repetidos y ordenados)");
            System.out.println("2. Ver primeros N numeros primos");
            System.out.println("3. Lista de productos (original)");
            System.out.println("4. Volver al menu principal");
            System.out.print("Elige opcion: ");
            subop = sc.nextInt();
            sc.nextLine();

            switch (subop) {
                case 1 -> new NombresPOO().ejecutar();
                case 2 -> new PrimosPOO().ejecutar();
                case 3 -> TiendaApp.ejecutar();
                case 4 -> System.out.println("Volviendo...");
                default -> System.out.println("Opción invalida.");
            }

        } while (subop != 4);
    }

    // Submenú EVENTOS
    public static void menuEventos(Scanner sc) {
        int subop;
        do {
            System.out.println("\n--- MODULO EVENTOS ---");
            System.out.println("1. Contador con botones (simulado)");
            System.out.println("2. Lista de nombres (sin repetidos y ordenados)");
            System.out.println("3. Ver primeros N numeros primos");
            System.out.println("4. Volver al menu principal");
            System.out.print("Elige opcion: ");
            subop = sc.nextInt();
            sc.nextLine();

            switch (subop) {
                case 1 -> new ContadorEventos(); // ejecuta en constructor
                case 2 -> new NombresEventos().ejecutar();
                case 3 -> new PrimosEventos().ejecutar();
                case 4 -> System.out.println("Volviendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (subop != 4);
    }

    // Submenú FUNCIONAL
    public static void menuFuncional(Scanner sc) {
        int subop;
        do {
            System.out.println("\n--- MODULO FUNCIONAL ---");
            System.out.println("1. Palabras con vocal (original)");
            System.out.println("2. Lista de nombres sin repetidos y ordenados");
            System.out.println("3. Ver primeros N numeros primos");
            System.out.println("4. Volver al menu principal");
            System.out.print("Elige opcion: ");
            subop = sc.nextInt();
            sc.nextLine();

            switch (subop) {
                case 1 -> PalabrasFuncional.ejecutar();
                case 2 -> NombresFuncional.ejecutar();
                case 3 -> PrimosFuncional.ejecutar();
                case 4 -> System.out.println("Volviendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (subop != 4);
    }
}