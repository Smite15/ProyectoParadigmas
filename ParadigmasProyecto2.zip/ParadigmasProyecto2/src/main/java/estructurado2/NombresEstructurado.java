/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurado2;
import java.util.*;
/**
 *
 * @author Saul Mite
 */
public class NombresEstructurado {
    public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        Set<String> nombres = new HashSet<>();

        System.out.println("Ingresa nombres (deja en blanco para terminar):");

        while (true) {
            System.out.print("Nombre: ");
            String nombre = sc.nextLine().trim();

            if (nombre.isEmpty()) break;

            if (!nombres.add(nombre)) {
                System.out.println("Nombre repetido. Intenta con otro.");
            }
        }

        List<String> listaOrdenada = new ArrayList<>(nombres);
        Collections.sort(listaOrdenada);

        System.out.println("\nNombres ordenados:");
        for (String n : listaOrdenada) {
            System.out.println(n);
        }
    }
}
