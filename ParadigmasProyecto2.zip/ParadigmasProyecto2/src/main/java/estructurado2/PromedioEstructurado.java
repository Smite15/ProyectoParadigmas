/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurado2;
import java.util.*;

/**
 *
 * @author Saul Mite
 */
public class PromedioEstructurado {
public static void ejecutar() {
        Scanner scanner = new Scanner(System.in);
        List<Double> notas = new ArrayList<>();
        double suma = 0;

        System.out.println("Ingresa calificaciones (negativo para terminar):");
        while (true) {
            System.out.print("Nota: ");
            double nota = scanner.nextDouble();
            if (nota < 0) break;
            notas.add(nota);
            suma += nota;
        }

        if (notas.isEmpty()) {
            System.out.println("No se ingresaron notas.");
        } else {
            double promedio = suma / notas.size();
            System.out.printf("Promedio: %.2f\n", promedio);
        }
    }
}