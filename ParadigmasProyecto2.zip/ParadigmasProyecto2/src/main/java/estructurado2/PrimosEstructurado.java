/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estructurado2;
import java.util.Scanner;
/**
 *
 * @author Saul Mite
 */
public class PrimosEstructurado {
     public static void ejecutar() {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuantos numeros primos quieres ver?: ");
        int n = sc.nextInt();

        int contador = 0;
        int numero = 2;

        while (contador < n) {
            if (esPrimo(numero)) {
                System.out.print(numero + " ");
                contador++;
            }
            numero++;
        }

        System.out.println(); // salto de línea final
    }

    private static boolean esPrimo(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
}

